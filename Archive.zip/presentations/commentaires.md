1. conclusion: lien + licence sur LyonParallel
2. Dans le reste je ne vois aucune citation (endrullis, etc.) il faut en mettre et en dire du bien "malheureusement ces approches n'arrivent pas à prouver blabla"
